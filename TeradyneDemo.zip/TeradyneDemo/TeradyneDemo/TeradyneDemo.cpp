#include "pch.h"
#include "TeradyneDemo.h"


__declspec (dllexport) int start() {

	/////////////////////////////////////////////////////
	//------ This is the main application , It is an starting point

	return 1;
}

