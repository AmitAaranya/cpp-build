#pragma once

__declspec (dllexport) int start();
