#pragma once


__declspec (dllexport) int Add(int num1, int num2);
__declspec (dllexport) int Multiple(int num1, int num2);
__declspec (dllexport) int Subtraction(int num1, int num2);
__declspec (dllexport) int Division(int num1, int num2);